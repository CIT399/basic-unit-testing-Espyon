import org.junit.*;
import static org.junit.Assert.assertEquals;

public class TestJunit {
	
	String str = "5705247511";
	
	String str2 = "570-523-9979";
	
	String str3 = "570 524 9979";
	
	Telephone isformatted = new Telephone();
		
	@Test 
	public void testIsFormatted() {
		assertEquals(str,isformatted.isFormatted(str));
		
	}
	
	@Test 
	public void testIsFormatted2() {
		assertEquals(str2,isformatted.isFormatted(str2));
	
	}
	
	@Test 
	public void testIsFormatted3() {
		assertEquals(str3,isformatted.isFormatted(str3));
	
	}
	
}